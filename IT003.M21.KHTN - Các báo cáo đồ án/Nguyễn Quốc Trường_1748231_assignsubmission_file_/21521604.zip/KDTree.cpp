#include <vector>
#include <math.h>
#include <iostream>

using namespace std;

class Node
{
public:

    Node();
    Node(float, float);
    Node(const Node&);
    ~Node();

    float getX() const;
    float getY() const;
    bool getLevel() const;
    bool getHere() const;

    Node* getLeft() const;
    Node* getRight() const;
    Node* getParent() const;

    void setX(float);
    void setY(float);
    void setLevel(bool);
    void setHere(bool);

    void setLeft(Node*);
    void setRight(Node*);
    void setParent(Node*);

    void printNodes();

    void clearFlags();

    void findPath(Node*);

    void removeNode(Node*, Node*);

    void insertNode(Node*, Node*&);

    void distributeSubtree(Node*, Node*);

    void distributeTree(Node*, bool);

    double findDistance(Node*, Node*);


    Node* findNewRoot(Node*);

    Node* findClosestNode(Node*);

    Node* closestNodeInPath(Node*, Node*);

private:

    float x;
    float y;
    bool level;
    bool Here;

    Node* left;
    Node* right;
    Node* parent;
};

class kdTree
{
public:
    kdTree();
    kdTree(const kdTree&);
    virtual ~kdTree();

    Node* getRoot();
    Node* findClosestPoint(Node*);

    void print();
    void remove(Node*);
    void insert(Node*);

private:

    Node* root;
};

Node::Node()
{
    x = 0;
    y = 0;
    Here = false;
    left = NULL;
    right = NULL;
    parent = NULL;
}

Node::Node(float _x, float _y)
{
    x = _x;
    y = _y;
    Here = false;
    left = NULL;
    right = NULL;
    parent = NULL;
}

Node::Node(const Node& a)
{
    x = a.x;
    y = a.y;
    left = a.left;
    right = a.right;
    parent = a.parent;
}

Node::~Node()
{
    if (left != NULL)
        delete left;
    left = NULL;

    if (right != NULL)
        delete right;
    right = NULL;
}

float Node::getX() const
{
    return x;
}

float Node::getY() const
{
    return y;
}

bool Node::getLevel() const
{
    return level;
}

bool Node::getHere() const
{
    return Here;
}

Node* Node::getLeft() const
{
    return left;
}

Node* Node::getRight() const
{
    return right;
}

Node* Node::getParent() const
{
    return parent;
}

void Node::setX(float _x)
{
    x = _x;
}

void Node::setY(float _y)
{
    y = _y;
}

void Node::setLevel(bool _lev)
{
    level = _lev;
}

void Node::setHere(bool _here)
{
    Here = _here;
}

void Node::setRight(Node* newRight)
{
    right = newRight;
}

void Node::setLeft(Node* newLeft)
{
    left = newLeft;
}

void Node::setParent(Node* newParent)
{
    parent = newParent;
}

void Node::removeNode(Node* entry, Node* root)
{
    if (this->level)
    {
        if (this->x > entry->x)
        {
            if (left != NULL)
            {
                left->removeNode(entry, root);
            }
            return;
        }
        else if (this->x < entry->x)
        {
            if (right != NULL)
            {
                right->removeNode(entry, root);
            }
            return;
        }
        else
        {
            if (this->y == entry->y)
            {
                //Tim, xoa va can bang cay
                if (this->left == NULL && this->right == NULL)
                {
                    if (this->parent->left->x == this->x && this->parent->left->y == this->y)
                    {
                        this->parent->setLeft(NULL);
                        delete this;
                    }
                    else
                    {
                        this->parent->setRight(NULL);
                        delete this;
                    }
                }
                else
                {
                    if (this->parent == NULL)
                    {
                    }
                    else
                    {
                        if (this->parent->left->x == this->x && this->parent->left->y == this->y)
                        {
                            this->parent->setLeft(NULL);
                        }
                        else
                        {
                            this->parent->setRight(NULL);
                        }
                    }
                    this->distributeSubtree(this, root);
                }
            }
            else
            {
                if (right != NULL)
                {
                    right->removeNode(entry, root);
                }
                return;
            }
        }
    }

    else if (!(this->level))
    {
        if (this->y > entry->y)
        {
            if (left != NULL)
            {
                left->removeNode(entry, root);
            }
            return;
        }
        else if (this->y < entry->y)
        {
            if (right != NULL)
            {
                right->removeNode(entry, root);
            }
            return;
        }
        else
        {
            if (this->x == entry->x)
            {
                //Tim, xoa va can bang cay
                if (this->left == NULL && this->right == NULL)
                {
                    if (this->parent->left->x == this->x && this->parent->left->y == this->y)
                    {
                        this->parent->setLeft(NULL);
                        delete this;
                    }
                    else
                    {
                        this->parent->setRight(NULL);
                        delete this;
                    }
                }
                else
                {
                    if (this->parent == NULL)
                    {
                    }
                    else
                    {
                        if (this->parent->left->x == this->x && this->parent->left->y == this->y)
                        {
                            this->parent->setLeft(NULL);
                        }
                        else
                        {
                            this->parent->setRight(NULL);
                        }
                    }
                    this->distributeSubtree(this, root);
                }
            }
            else
            {
                if (right != NULL)
                {
                    right->removeNode(entry, root);
                }
                return;
            }
        }
    }
}

void Node::insertNode(Node* newNode, Node*& root)
{
    if (this->level)
    {
        if (this->x > newNode->x)
        {
            if (left != NULL)
                left->insertNode(newNode, root);
            else
            {
                //Thay doi bac cua node con
                newNode->setLevel(!(this->getLevel()));
                newNode->setParent(this);
                this->setLeft(newNode);
                return;
            }
        }
        else if (this->x < newNode->x)
        {
            if (right != NULL)
                right->insertNode(newNode, root);
            else
            {
                //Thay doi bac cua node con
                newNode->setLevel(!(this->getLevel()));
                newNode->setParent(this);
                this->setRight(newNode);
                return;
            }
        }
        else
        {
            if (this->y == newNode->y)
            {
                return;
            }
            else
            {
                if (right != NULL)
                    right->insertNode(newNode, root);
                else
                {
                    //Thay doi bac cua node con
                    newNode->setLevel(!(this->getLevel()));
                    newNode->setParent(this);
                    this->setRight(newNode);
                    return;
                }
            }
        }
    }

    else if (!(this->level))
    {
        if (this->y > newNode->y)
        {
            if (left != NULL)
                left->insertNode(newNode, root);
            else
            {
                //Thay doi bac cua node con
                newNode->setLevel(!(this->getLevel()));
                newNode->setParent(this);
                this->setLeft(newNode);
                return;
            }

        }
        else if (this->y < newNode->y)
        {
            if (right != NULL)
                right->insertNode(newNode, root);
            else
            {
                //Thay doi bac cua node con
                newNode->setLevel(!(this->getLevel()));
                newNode->setParent(this);
                this->setRight(newNode);
                return;
            }
        }
        else
        {
            if (this->x == newNode->x)
            {
                return;
            }
            else
            {
                if (right != NULL)
                    right->insertNode(newNode, root);
                else
                {
                    //Thay doi bac cua node con
                    newNode->setLevel(!(this->getLevel()));
                    newNode->setParent(this);
                    this->setRight(newNode);
                    return;
                }
            }
        }
    }
}

Node* Node::findClosestNode(Node* entry)
{
    vector<Node>path;

    //bat dau bang vector root
    findPath(entry);

    //diem gan nhat truoc do
    //dat dia chi khoi dau la NULL 
    Node dummy;
    Node* previousSmallest = &dummy;

    //diem gan nhat hien tai trong pham vi tim kiem
    Node* smallestNode = closestNodeInPath(entry, this);

    while (!(previousSmallest->getX() == smallestNode->getX() && previousSmallest->getY() == smallestNode->getY()))
    {
        previousSmallest = smallestNode;

        //tim node con chua duoc duyet qua cua node gan nhat
        bool checkedLeft = false;
        bool checkedRight = false;

        if (smallestNode->getLeft() != NULL && smallestNode->left->Here)
        {
            checkedLeft = true;
        }
        else if (smallestNode->getRight() != NULL && smallestNode->right->Here)
        {
            checkedRight = true;
        }

        this->clearFlags();

        //xac dinh pham vi tim kiem moi
        if (checkedLeft)
        {
            //them node gan nhat vao pham vi moi
            smallestNode->setHere(true);
            if (smallestNode->getRight() != NULL)
                (smallestNode->getRight())->findPath(entry);
        }
        else if (checkedRight)
        {
            //them node gan nhat vao pham vi moi
            smallestNode->setHere(true);
            if (smallestNode->getLeft() != NULL)
                (smallestNode->getLeft())->findPath(entry);
        }
        else
        {
            smallestNode->setHere(true);
            smallestNode->findPath(entry);
        }

        //cap nhat lai node gan nhat moi
        smallestNode = closestNodeInPath(entry, smallestNode);
    }
    return smallestNode;
}

Node* Node::closestNodeInPath(Node* entry, Node* root)
{
    double distanceHolder = 100000000;
    Node* nodeHolder;

    Node* current = root;

    //neu co duy nhat mot node tren cay
    //neu co nhieu node, cac dong nay se khong tao nen su khac biet
    nodeHolder = current;

    bool noAvailableNode = false;

    while (!noAvailableNode)
    {
        double tempDistance = findDistance(entry, current);

        if (tempDistance < distanceHolder)
        {
            distanceHolder = tempDistance;
            nodeHolder = current;
        }

        bool nextNodeIsLeft = false;
        bool nextNodeIsRight = false;

        //tim node tiep theo can di den
        if (current->left != NULL)
        {
            if (current->left->Here == true)
            {
                nextNodeIsLeft = true;
                noAvailableNode = false;
                current = current->left;
            }
            else {
                noAvailableNode = true;
            }
        }
        if (current->right != NULL && !nextNodeIsLeft)
        {
            if (current->right->Here == true)
            {
                nextNodeIsRight = true;
                noAvailableNode = false;
                current = current->right;
            }
            else
            {
                noAvailableNode = true;
            }
        }
        if (current->left == NULL && current->right == NULL && !nextNodeIsLeft && !nextNodeIsRight)
        {
            noAvailableNode = true;
        }
    }

    return nodeHolder;
}

void Node::findPath(Node* entry)
{
    this->setHere(true);

    if (this->level)
    {
        if (this->x > entry->getX())
        {
            if (left != NULL)
                left->findPath(entry);
        }
        else if (this->x < entry->getX())
        {
            if (right != NULL)
                right->findPath(entry);
        }
        else {
            if (this->y == entry->getY())
            {
            }
            else
            {
                if (right != NULL)
                    right->findPath(entry);
            }
        }
    }

    else
    {
        if (this->y > entry->getY())
        {
            if (left != NULL)
                left->findPath(entry);
        }
        else if (this->y < entry->getY())
        {
            if (right != NULL)
                right->findPath(entry);
        }
        else
        {
            if (this->x == entry->getX())
            {
            }
            else
            {
                if (right != NULL)
                    right->findPath(entry);
                else
                {
                }
            }
        }
    }
}

void Node::printNodes()
{
    if (left != NULL)
        left->printNodes();

    if (this->parent != NULL)
    {
        cout << "(" << this->x << "," << this->y << "); Bac: " << level << "; Node cha: (" << this->getParent()->x << "," << this->getParent()->y << ")." << endl;
    }
    else
    {
        cout << "(" << this->x << "," << this->y << "); Bac: " << level << "; Day la node goc." << endl;
    }

    if (right != NULL)
        right->printNodes();
}

void Node::clearFlags()
{
    if (left != NULL)
        left->clearFlags();

    if (this->Here)
    {
        this->setHere(false);
    }
    if (right != NULL)
        right->clearFlags();
}

void Node::distributeSubtree(Node* entry, Node* root)
{
    if (this == NULL)
        return;

    if (this->left != NULL)
        left->distributeSubtree(entry, root);

    if (this->right != NULL)
        right->distributeSubtree(entry, root);

    if (!(this->x == entry->x && this->y == entry->y))
    {
        this->setHere(false);
        this->setLeft(NULL);
        this->setRight(NULL);
        this->setParent(NULL);
        root->insertNode(this, root);
    }
    else
    {
        this->setRight(NULL);
        this->setLeft(NULL);
        this->setParent(NULL);
        delete this;
    }
}

double Node::findDistance(Node* node1, Node* node2)
{
    float x1 = node1->getX();
    float y1 = node1->getY();
    float x2 = node2->getX();
    float y2 = node2->getY();

    double distance = sqrt(pow((x1 - x2), 2) + pow((y1 - y2), 2));

    return distance;
}

kdTree::kdTree()
{
    root = NULL;
}

kdTree::~kdTree()
{
    if (root != NULL)
    {
        delete root;
    }
    root = NULL;
}

Node* kdTree::getRoot()
{
    return root;
}

void kdTree::insert(Node* newEntry)
{
    if (root == NULL)
    {
        newEntry->setLevel(true);
        newEntry->setParent(NULL);
        root = newEntry;
    }
    else {
        root->insertNode(newEntry, root);
    }
}

void kdTree::remove(Node* entry)
{
    if (root == NULL)
        return;
    else
    {
        root->removeNode(entry, root);
    }
}

Node* kdTree::findClosestPoint(Node* entry)
{
    if (root == NULL)
        return NULL;
    else
    {
        return(root->findClosestNode(entry));
    }
}

void kdTree::print()
{
    if (root == NULL)
        return;
    else
        root->printNodes();
}

int main()
{
    kdTree* Tree = new kdTree();

    float a, b, c, d;
    cin >> a >> b >> c >> d; 

    Node* nodeO = new Node(0, 0);
    Node* nodeA = new Node(5, 3);
    Node* nodeB = new Node(7, 2);
    Node* nodeC = new Node(6, 1);
    Node* nodeD = new Node(a, b);
    Node* nodeE = new Node(c, d);

    Tree->insert(nodeO);
    Tree->insert(nodeA);
    Tree->insert(nodeB);
    Tree->insert(nodeC);
    Tree->insert(nodeD);
    Tree->insert(nodeE);

    Tree->remove(nodeB);

    Tree->print();

    return 0;
}